import { useState, useEffect, ChangeEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, 
  Wind, 
  Coffee, 
  Moon, 
  Zap, 
  Smile, 
  ChevronRight, 
  RefreshCw,
  CheckCircle2,
  Heart,
  Settings,
  Compass,
  Flower2
} from 'lucide-react';
import { getMoodSuggestions, MoodSuggestion } from './services/geminiService';

const MOOD_CHIPS = [
  { label: 'Stressed', icon: <Zap className="w-4 h-4" /> },
  { label: 'Tired', icon: <Moon className="w-4 h-4" /> },
  { label: 'Bored', icon: <Coffee className="w-4 h-4" /> },
  { label: 'Anxious', icon: <Wind className="w-4 h-4" /> },
];

export default function App() {
  const [mood, setMood] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<MoodSuggestion | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleGetSuggestions = async (inputMood?: string) => {
    const finalMood = (inputMood || mood).trim();
    if (!finalMood) {
      setError('Please share how you are feeling.');
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const suggestions = await getMoodSuggestions(finalMood);
      setResult(suggestions);
    } catch (err) {
      setError('Failed to get suggestions. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleChipClick = (chipLabel: string) => {
    if (loading) return;
    setMood(chipLabel);
    handleGetSuggestions(chipLabel);
  };

  const handleInputChange = (e: ChangeEvent<HTMLTextAreaElement>) => {
    setMood(e.target.value);
    if (error) setError(null);
  };

  return (
    <div className="min-h-screen flex flex-col bg-surface">
      {/* Header */}
      <header className="w-full py-6 px-8 flex justify-center items-center max-w-7xl mx-auto">
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex items-center gap-2"
        >
          <span className="text-2xl font-light tracking-tight text-primary">SereneFlow</span>
        </motion.div>
      </header>

      <main className="flex-1 flex flex-col items-center justify-start md:justify-center w-full max-w-3xl mx-auto px-6 pt-12 pb-32">
        <AnimatePresence mode="wait">
          {!result ? (
            <motion.div
              key="input-screen"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="w-full text-center space-y-8 md:space-y-12"
            >
              <div className="space-y-4">
                <h1 className="text-4xl md:text-5xl font-extrabold tracking-tighter text-on-surface leading-tight">
                  Mood-Based Suggestion App
                </h1>
                <p className="text-lg md:text-xl text-on-surface-variant max-w-xl mx-auto font-medium">
                  Get simple suggestions based on how you feel.
                </p>
              </div>

              <div className="space-y-8">
                <div className="flex flex-wrap justify-center gap-3">
                  {MOOD_CHIPS.map((chip) => (
                    <button
                      key={chip.label}
                      onClick={() => handleChipClick(chip.label)}
                      disabled={loading}
                      className="flex items-center gap-2 px-6 py-2.5 rounded-full bg-surface-container-low text-on-surface-variant hover:bg-secondary-container hover:text-on-secondary-container transition-all duration-300 border border-transparent hover:border-secondary-container text-sm font-semibold disabled:opacity-50"
                    >
                      {chip.icon}
                      {chip.label}
                    </button>
                  ))}
                </div>

                <div className="relative group">
                  <div className="absolute -inset-1 bg-gradient-to-tr from-primary/10 to-secondary/10 rounded-2xl blur-xl opacity-0 group-focus-within:opacity-100 transition-opacity duration-500"></div>
                  <div className="relative bg-surface-container-lowest rounded-2xl shadow-[0_8px_32px_rgba(49,50,52,0.06)] overflow-hidden">
                    <textarea
                      value={mood}
                      onChange={handleInputChange}
                      disabled={loading}
                      className="w-full px-8 py-6 text-lg bg-transparent border-none focus:ring-0 placeholder:text-outline-variant resize-none min-h-[120px] disabled:opacity-50"
                      placeholder="How are you feeling today?"
                    />
                  </div>
                  {error && (
                    <motion.p 
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="absolute -bottom-6 left-0 right-0 text-red-500 text-sm font-medium"
                    >
                      {error}
                    </motion.p>
                  )}
                </div>

                <button
                  onClick={() => handleGetSuggestions()}
                  disabled={loading}
                  className="group relative inline-flex items-center justify-center px-10 py-4 font-bold tracking-wide text-white transition-all duration-300 rounded-full bg-gradient-to-br from-primary to-primary-dim hover:scale-105 hover:shadow-lg active:scale-95 disabled:opacity-50 disabled:scale-100"
                >
                  {loading ? (
                    <RefreshCw className="w-5 h-5 animate-spin mr-2" />
                  ) : (
                    <Sparkles className="w-5 h-5 mr-2" />
                  )}
                  {loading ? 'Finding Stillness...' : 'Get Suggestions'}
                </button>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="result-screen"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full space-y-12"
            >
              <div className="text-center space-y-4">
                <h2 className="text-4xl md:text-5xl font-light tracking-tight text-on-background leading-tight">
                  Your path to <span className="text-primary italic">stillness</span>
                </h2>
                <p className="text-on-surface-variant text-lg font-light tracking-wide max-w-md mx-auto">
                  Gentle steps tailored for your current state of being.
                </p>
              </div>

              <div 
                className="w-full opacity-60 hover:opacity-100 transition-opacity cursor-pointer" 
                onClick={() => !loading && setResult(null)}
              >
                <div className="bg-surface-container-low rounded-xl px-8 py-6 flex items-center justify-between shadow-sm">
                  <span className="text-on-surface-variant font-light italic">"{mood}"</span>
                  <span className="text-primary text-sm font-medium">Edit Mood</span>
                </div>
              </div>

              <div className="bg-surface-container-lowest rounded-3xl p-2 shadow-[0_20px_50px_rgba(0,0,0,0.05)]">
                <div className="bg-surface-container-low rounded-[2rem] p-8 md:p-12 space-y-10">
                  {loading ? (
                    <div className="flex flex-col items-center justify-center py-12 space-y-4">
                      <RefreshCw className="w-12 h-12 text-primary animate-spin" />
                      <p className="text-on-surface-variant animate-pulse">Refreshing your sanctuary...</p>
                    </div>
                  ) : (
                    <>
                      <div className="space-y-8">
                        {result.suggestions.map((suggestion, idx) => (
                          <motion.div
                            key={idx}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: idx * 0.1 }}
                            className="flex items-start gap-6 group"
                          >
                            <div className="bg-secondary-container text-on-secondary-container rounded-full p-3 flex items-center justify-center shadow-sm">
                              <CheckCircle2 className="w-6 h-6" />
                            </div>
                            <div className="space-y-1">
                              <h3 className="text-xl font-medium text-on-surface leading-snug">
                                {suggestion.split(':')[0]}
                              </h3>
                              {suggestion.includes(':') && (
                                <p className="text-on-surface-variant font-light">
                                  {suggestion.split(':').slice(1).join(':').trim()}
                                </p>
                              )}
                            </div>
                          </motion.div>
                        ))}
                      </div>

                      <div className="h-px w-full bg-gradient-to-r from-transparent via-outline-variant/20 to-transparent"></div>

                      <div className="text-center">
                        <p className="text-secondary font-medium italic tracking-wide text-lg opacity-90">
                          "{result.motivationalMessage}"
                        </p>
                      </div>
                    </>
                  )}
                </div>
              </div>

              <div className="flex justify-center">
                <button
                  onClick={() => handleGetSuggestions()}
                  disabled={loading}
                  className="bg-gradient-to-br from-primary to-primary-dim text-white px-12 py-4 rounded-full font-medium tracking-wide shadow-xl hover:scale-105 active:scale-95 transition-all duration-300 flex items-center gap-3 disabled:opacity-50"
                >
                  <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
                  {loading ? 'Refreshing...' : 'Refresh suggestions'}
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Bottom Nav */}
      <nav className="fixed bottom-0 left-0 w-full z-50 flex justify-around items-center h-24 bg-surface/80 backdrop-blur-xl rounded-t-[3rem] px-6 pb-safe shadow-[0_-4px_40px_rgba(0,0,0,0.05)]">
        <button className="flex flex-col items-center justify-center text-primary p-3 transition-all">
          <Flower2 className="w-6 h-6" />
          <span className="text-[11px] font-medium uppercase tracking-widest mt-1">Reflect</span>
        </button>
        <button className="flex flex-col items-center justify-center text-on-surface-variant p-3 hover:bg-surface-container rounded-full transition-all">
          <Compass className="w-6 h-6" />
          <span className="text-[11px] font-medium uppercase tracking-widest mt-1">Explore</span>
        </button>
        <button className="flex flex-col items-center justify-center text-on-surface-variant p-3 hover:bg-surface-container rounded-full transition-all">
          <Settings className="w-6 h-6" />
          <span className="text-[11px] font-medium uppercase tracking-widest mt-1">Settings</span>
        </button>
      </nav>

      {/* Background Decoration */}
      <div className="fixed -top-24 -left-24 w-96 h-96 bg-primary/5 rounded-full blur-[100px] pointer-events-none -z-10"></div>
      <div className="fixed top-1/2 -right-48 w-[30rem] h-[30rem] bg-secondary/5 rounded-full blur-[120px] pointer-events-none -z-10"></div>
    </div>
  );
}
