import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface MoodSuggestion {
  suggestions: string[];
  motivationalMessage: string;
}

const DEFAULT_SUGGESTIONS: MoodSuggestion = {
  suggestions: [
    "Take three slow, deep breaths to center yourself.",
    "Step away from your screen for a five-minute stretch.",
    "Drink a glass of water and focus on the sensation."
  ],
  motivationalMessage: "You're doing great, take it one step at a time."
};

export async function getMoodSuggestions(mood: string): Promise<MoodSuggestion> {
  const model = "gemini-3-flash-preview";
  
  // Normalize input
  const normalizedMood = mood.trim().toLowerCase();
  
  const systemInstruction = `
    You are a calm, supportive, and practical mood assistant for students. 
    Based on the user's mood or feelings, provide exactly three short, actionable, and practical suggestions to help them feel better or more focused.
    Also provide one concise, supportive motivational message.
    
    Tone: Calm, supportive, practical, and empathetic.
    Constraint: Exactly 3 suggestions. No more, no less.
    Constraint: Exactly 1 motivational message.
    Avoid: Medical advice, long paragraphs, or verbose explanations.
    
    Output must be a JSON object with the following structure:
    {
      "suggestions": ["suggestion 1", "suggestion 2", "suggestion 3"],
      "motivationalMessage": "concise message"
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: [{ parts: [{ text: `User mood: ${normalizedMood}` }] }],
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            suggestions: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Three short actionable suggestions.",
              minItems: 3,
              maxItems: 3,
            },
            motivationalMessage: {
              type: Type.STRING,
              description: "A concise supportive message.",
            },
          },
          required: ["suggestions", "motivationalMessage"],
        },
      },
    });

    const text = response.text?.trim();
    if (!text) return DEFAULT_SUGGESTIONS;

    const result = JSON.parse(text);
    return {
      suggestions: Array.isArray(result.suggestions) && result.suggestions.length === 3 
        ? result.suggestions 
        : DEFAULT_SUGGESTIONS.suggestions,
      motivationalMessage: result.motivationalMessage || DEFAULT_SUGGESTIONS.motivationalMessage,
    };
  } catch (error) {
    console.error("Error fetching mood suggestions:", error);
    return DEFAULT_SUGGESTIONS;
  }
}
